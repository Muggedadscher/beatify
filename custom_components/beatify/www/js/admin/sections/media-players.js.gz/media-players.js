/**
 * Beatify Admin — Media-Players setup-section (#1279 Schritt 4b/6).
 *
 * Extracted from admin.js: the media-player list render + radio-selection +
 * platform-capability cluster, plus the provider-option/-warning UI that gates
 * the music-service provider chips based on the selected speaker's capabilities.
 *
 * State: reads/writes the shared `adminState` object (admin/state.js) directly.
 *
 * Cross-section: imports `updateStartButtonState` from playlists.js (the shared
 * start-button validation helper). `updateProviderOptions` toggles the
 * `.chip[data-provider]` buttons that the game-settings section wires up — the
 * music-service "section" has no separate cluster of its own (the live provider
 * UI is the chips owned by game-settings + this capability gate), so it is NOT
 * a standalone module (see PR body).
 *
 * The no-compatible-players empty state offers a "Refresh" button. It used to
 * be an inline `onclick="loadStatus()"` that only resolved because admin.js
 * published its core `loadStatus` on `window`. #2637 replaced that with a
 * `refreshStatus` dependency handed in through `initMediaPlayers()`, so this
 * module no longer needs admin.js to have run first for its own button to work.
 */

import { adminState } from '../state.js';
import { STORAGE_LAST_PLAYER, PLATFORM_LABELS } from '../constants.js';
import { PROVIDERS } from '../../providers.generated.js';
import { updateStartButtonState } from './playlists.js';
import { tr } from '../util.js';

// BeatifyUtils is a classic global script loaded before admin.min.js (module,
// deferred), so this is safe at module init. Mirrors the admin.js pattern.
const utils = window.BeatifyUtils || {};

// Admin-core dependencies, injected once at init (#2637).
const deps = {
    refreshStatus: null,   // admin.js `loadStatus`
};

/**
 * Wire the media-players section's admin-core dependencies once at init.
 *
 * @param {{ refreshStatus?: Function }} injected - `refreshStatus` re-runs the
 *   admin core's status fetch; the no-compatible-players empty state's Refresh
 *   button calls it.
 */
export function initMediaPlayers(injected = {}) {
    deps.refreshStatus = injected.refreshStatus || null;
}

/**
 * Update media player summary badge
 * @param {string} playerName - Friendly name of selected player
 */
export function updateMediaPlayerSummary(playerName) {
    const summary = document.getElementById('media-player-summary');
    if (summary) {
        summary.textContent = playerName || 'Select...';
    }
}

/**
 * #1619-followup: decide whether a re-render should keep the current selection.
 *
 * `renderMediaPlayers()` used to blindly null `adminState.selectedMediaPlayer`
 * on every call, then re-derive it from localStorage. That silently dropped a
 * still-valid choice whenever it wasn't re-derivable — e.g. a speaker that is
 * transiently `unavailable` (filtered out of the rendered list) during a routine
 * status-poll re-render. We keep the selection as long as the chosen player is
 * still present in the incoming payload (available OR unavailable); only a player
 * that has actually disappeared clears it.
 *
 * @param {string|null} prevSelectedId - entityId of the current selection (or null)
 * @param {Array} players - raw players payload (before the unavailable filter)
 * @returns {boolean}
 */
export function _shouldKeepSelection(prevSelectedId, players) {
    return !!prevSelectedId && (players || []).some((p) => p.entity_id === prevSelectedId);
}

/**
 * Render media players list grouped by platform with capability info
 * Filters out unavailable players
 * @param {Array} players
 */
export function renderMediaPlayers(players) {
    const container = document.getElementById('media-players-list');
    // Remove data-i18n and skeleton state when real content renders
    container?.removeAttribute('data-i18n');
    container?.removeAttribute('aria-busy');
    container?.classList.remove('skeleton-list');
    const totalPlayers = players ? players.length : 0;

    // #1619-followup: only drop the selection when the chosen player is actually
    // gone from the new payload. A blind reset here silently lost a still-valid
    // choice (e.g. a transiently-unavailable speaker) across status-poll
    // re-renders. The localStorage auto-select below still re-derives it when the
    // player is back in the available list.
    const prevSelectedId = adminState.selectedMediaPlayer?.entityId || null;
    if (!_shouldKeepSelection(prevSelectedId, players)) {
        adminState.selectedMediaPlayer = null;
    }

    // Filter out unavailable players
    const availablePlayers = (players || []).filter(p => p.state !== 'unavailable');

    // Hide validation message when showing empty states (avoid redundant messaging)
    const validationMsg = document.getElementById('media-player-validation-msg');

    if (totalPlayers === 0) {
        // No compatible players found - show setup message with MA link
        container.innerHTML = `
            <div class="no-players-message">
                <h3>${tr('admin.noCompatiblePlayersTitle', '🎵 No Compatible Players Found')}</h3>
                <p>${tr('admin.noCompatiblePlayersDesc', 'Beatify works with Music Assistant, Sonos, and Alexa players.')}</p>
                <p><strong>${tr('admin.recommendedLabel', 'Recommended:')}</strong> ${tr('admin.installMusicAssistant', 'Install Music Assistant for the best experience with any speaker.')}</p>
                <div class="button-group">
                    <a href="https://music-assistant.io/getting-started/"
                       target="_blank" class="btn btn-secondary">
                        ${tr('admin.musicAssistantSetupGuide', '📖 Music Assistant Setup Guide')}
                    </a>
                    <button type="button" data-action="refresh-status" class="btn btn-primary">
                        ${tr('admin.refresh', '🔄 Refresh')}
                    </button>
                </div>
            </div>
        `;
        container.querySelector('[data-action="refresh-status"]')
            ?.addEventListener('click', () => { deps.refreshStatus?.(); });
        if (validationMsg) {
            validationMsg.classList.add('hidden');
        }
        // Disable start button when no players
        const startBtn = document.getElementById('start-game');
        if (startBtn) startBtn.disabled = true;
        return;
    }

    if (availablePlayers.length === 0) {
        // Players exist but all unavailable
        const docsLink = adminState.mediaPlayerDocsUrl
            ? `<a href="${utils.escapeHtml(adminState.mediaPlayerDocsUrl)}" target="_blank" rel="noopener">Troubleshooting</a>`
            : '';
        container.innerHTML = `
            <div class="empty-state">
                <p class="status-error">All media players are unavailable. Check your devices are powered on.</p>
                ${docsLink ? `<p style="margin-top: 12px;">${docsLink}</p>` : ''}
            </div>
        `;
        if (validationMsg) {
            validationMsg.classList.add('hidden');
        }
        return;
    }

    // Render all players with platform badges on each item
    container.innerHTML = availablePlayers.map(player => renderPlayerItem(player)).join('');
    attachPlayerSelectionHandlers();

    // Try to auto-select last used player from localStorage
    const lastPlayerId = localStorage.getItem(STORAGE_LAST_PLAYER);
    if (lastPlayerId) {
        // Match the radio input specifically — the wrapper .media-player-item div
        // also carries data-entity-id and appears first in DOM order, so a bare
        // [data-entity-id] selector grabs the div: .checked is a no-op and
        // handleMediaPlayerSelect reads undefined data-state. Mirror admin.js
        // hydrateFromStorage and target .media-player-radio (CSS.escape the id).
        const lastPlayerRadio = container.querySelector(
            `.media-player-radio[data-entity-id="${CSS.escape(lastPlayerId)}"]`
        );
        if (lastPlayerRadio) {
            lastPlayerRadio.checked = true;
            handleMediaPlayerSelect(lastPlayerRadio, true); // true = skip localStorage save
            // Collapse section since we have a valid selection
            const section = document.getElementById('media-players');
            if (section) {
                section.classList.add('collapsed');
                const toggle = document.getElementById('media-players-toggle');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
            }
        }
    }
}

/**
 * Expand the speaker section and scroll it into view (#2269).
 *
 * The inverse of the collapse in renderMediaPlayers above: once a speaker was
 * picked the section folds away, which is fine until that speaker disappears.
 * The start-game error banner calls this so "Select Speaker" actually leads
 * somewhere instead of leaving the host to find a collapsed section below the
 * home hero on a phone.
 */
export function expandMediaPlayersSection() {
    const section = document.getElementById('media-players');
    if (!section) return;
    section.classList.remove('collapsed');
    const toggle = document.getElementById('media-players-toggle');
    if (toggle) toggle.setAttribute('aria-expanded', 'true');
    if (typeof section.scrollIntoView === 'function') {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// #2713: one place that knows how a provider id becomes a DOM attribute.
// `apple_music` -> `data-supports-apple-music` -> `dataset.supportsAppleMusic`.
// These three spellings of the same provider used to be typed out per provider
// in three separate blocks below, which is why `amazon_music` reached the
// dataset but never the payload and its chip could not enable.
function supportsAttr(providerId) {
    return `data-supports-${providerId.replace(/_/g, '-')}`;
}

function supportsDatasetKey(providerId) {
    return `supports${providerId
        .split('_')
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join('')}`;
}

/** The `data-supports-*` attributes for one backend player record. */
function supportsAttributes(player) {
    return PROVIDERS
        .map((p) => `${supportsAttr(p.id)}="${player[p.supportsKey]}"`)
        .join('\n                       ');
}

/** `{ providerId: boolean }` read back off a rendered radio's dataset. */
function supportsFromDataset(dataset) {
    const supports = {};
    for (const p of PROVIDERS) {
        supports[p.id] = dataset[supportsDatasetKey(p.id)] === 'true';
    }
    return supports;
}

/** Does the selected player serve this provider? Unknown player = yes. */
function playerSupports(player, providerId) {
    if (!player || !player.supports) return true;
    return player.supports[providerId] === true;
}

/**
 * Render a single player item with platform badge and capability data attributes
 * @param {Object} player - Player object from backend
 * @returns {string} HTML string
 */
export function renderPlayerItem(player) {
    const info = PLATFORM_LABELS[player.platform] || { icon: '🔈', label: player.platform };
    const platformBadge = `<span class="platform-badge platform-badge--${utils.escapeHtml(player.platform)}">${info.icon} ${info.label}</span>`;

    return `
        <div class="media-player-item list-item is-selectable"
             data-entity-id="${utils.escapeHtml(player.entity_id)}"
             data-platform="${utils.escapeHtml(player.platform)}"
             ${supportsAttributes(player)}>
            <label class="radio-label">
                <input type="radio"
                       class="media-player-radio"
                       name="media-player"
                       data-entity-id="${utils.escapeHtml(player.entity_id)}"
                       data-state="${utils.escapeHtml(player.state)}"
                       data-platform="${utils.escapeHtml(player.platform)}"
                       ${supportsAttributes(player)}>
                <span class="player-info">
                    <span class="player-name">${utils.escapeHtml(player.friendly_name)}</span>
                    ${platformBadge}
                </span>
            </label>
            <span class="meta">
                <span class="state-dot state-${utils.escapeHtml(player.state)}"></span>
                ${utils.escapeHtml(player.state)}
            </span>
        </div>
    `;
}

/**
 * Attach event handlers to player selection elements
 */
export function attachPlayerSelectionHandlers() {
    const container = document.getElementById('media-players-list');
    if (!container) return;

    // Attach event listeners to radio buttons
    container.querySelectorAll('.media-player-radio').forEach(radio => {
        radio.addEventListener('change', function() {
            handleMediaPlayerSelect(this);
        });
    });

    // Make entire row clickable (for hidden input UX)
    container.querySelectorAll('.media-player-item').forEach(item => {
        item.addEventListener('click', function(e) {
            // Don't double-trigger if clicking on the radio or within the label
            if (e.target.classList.contains('media-player-radio') || e.target.closest('.radio-label')) return;
            const radio = item.querySelector('.media-player-radio');
            if (radio && !radio.checked) {
                radio.checked = true;
                handleMediaPlayerSelect(radio);
            }
        });
    });
}

/**
 * Handle media player radio button selection (AC4)
 * Updates provider options based on platform capabilities.
 * @param {HTMLInputElement} radio
 * @param {boolean} skipSave - If true, don't save to localStorage (used for auto-select)
 */
export function handleMediaPlayerSelect(radio, skipSave = false) {
    const entityId = radio.dataset.entityId;
    const state = radio.dataset.state;
    const platform = radio.dataset.platform;

    // Update module state with platform capabilities. One `supports` map keyed
    // by provider id, rather than a named field per provider (#2713).
    adminState.selectedMediaPlayer = {
        entityId,
        state,
        platform,
        supports: supportsFromDataset(radio.dataset),
    };

    // Apply the device to an EXISTING lobby immediately (server no-ops when
    // no lobby-phase game exists). Without this, rooms keep the device they
    // were created with and a switch only took effect one game later.
    try {
        window.BeatifyAuth?.fetch('/beatify/api/game/update-lobby', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ media_player: entityId }),
        });
    } catch (e) { /* fire-and-forget */ }

    // Update visual selection
    document.querySelectorAll('.media-player-item').forEach(item => {
        item.classList.remove('is-selected');
    });
    const playerItem = radio.closest('.media-player-item');
    playerItem.classList.add('is-selected');

    // Get player name for summary
    const playerName = playerItem.querySelector('.player-name')?.textContent?.trim() || entityId;
    updateMediaPlayerSummary(playerName);

    // Show Music Service section
    const musicServiceSection = document.getElementById('music-service');
    if (musicServiceSection) {
        musicServiceSection.classList.remove('hidden');
    }

    // Update provider options based on platform capabilities
    updateProviderOptions(adminState.selectedMediaPlayer);

    // Update warning message
    updateProviderWarning(adminState.selectedMediaPlayer);

    // Save to localStorage
    if (!skipSave) {
        try {
            localStorage.setItem(STORAGE_LAST_PLAYER, entityId);
        } catch (e) {
            console.warn('Failed to save last player:', e);
        }
        // #1927 write-through: mirror the pick to the server blob immediately.
        // Until now only the wizard did that, so a speaker chosen here stayed
        // local — and reconcileSavedSetup() (which lets the server win) would
        // hand this device back the older wizard pick on the next load. With
        // the write-through there is one source of truth and this selection IS
        // the newest one. Best-effort: a failed POST never blocks the game.
        try {
            globalThis.BeatifyPersistSetup?.();
        } catch (e) {
            console.warn('Failed to persist speaker to server:', e);
        }
    }

    updateStartButtonState();
}

/**
 * Update provider button states based on selected player capabilities
 * @param {Object} player - Selected player with capability flags
 */
export function updateProviderOptions(player) {
    // #2713: one loop over the registry. This used to be a `const xBtn =`
    // lookup, an `if (xBtn)` toggle and a "fall back to Spotify" block per
    // provider — six of each, and the Crate Digger chip that admin.html has
    // shipped since #1590 was in none of them, so it never dimmed.
    const chipFor = (id) => document.querySelector(`.chip[data-provider="${id}"]`);
    const spotifyBtn = chipFor('spotify');

    for (const p of PROVIDERS) {
        const btn = chipFor(p.id);
        if (!btn) continue;  // not every provider has a chip in the flat admin
        const supported = playerSupports(player, p.id);
        btn.disabled = !supported;
        btn.classList.toggle('chip--disabled', !supported);
    }

    // If current selection is now disabled, switch to Spotify.
    const selected = adminState.selectedProvider;
    if (selected && selected !== 'spotify' && !playerSupports(player, selected)) {
        document.querySelectorAll('.chip[data-provider]').forEach(c => c.classList.remove('chip--active'));
        if (spotifyBtn) spotifyBtn.classList.add('chip--active');
        adminState.selectedProvider = 'spotify';
    }

    // Show hint for disabled providers. A provider Music Assistant can serve
    // is named in the MA line; one it cannot (Amazon Music, which needs an
    // Echo) gets its own line from the registry's own wording.
    const hint = document.getElementById('provider-hint');
    if (hint) {
        const maSpeakerNeeded = [];
        const otherParts = [];
        for (const p of PROVIDERS) {
            if (p.id === 'spotify' || playerSupports(player, p.id)) continue;
            if (p.platforms.includes('music_assistant')) {
                maSpeakerNeeded.push(p.label);
            } else if (p.id === 'amazon_music') {
                otherParts.push('Amazon Music requires an Amazon Echo (alexa_media)');
            }
        }

        const hintParts = [];
        if (maSpeakerNeeded.length > 0) {
            hintParts.push(`${maSpeakerNeeded.join(' and ')} require${maSpeakerNeeded.length === 1 ? 's' : ''} a Music Assistant speaker`);
        }
        hintParts.push(...otherParts);

        if (hintParts.length > 0) {
            hint.textContent = hintParts.join(' · ');
            hint.classList.remove('hidden');
        } else {
            hint.classList.add('hidden');
        }
    }
}

/**
 * Update provider warning based on selected speaker platform
 * Shows setup requirements and caveats per platform
 * @param {Object} player - Selected player with platform info
 */
export function updateProviderWarning(player) {
    const warningEl = document.getElementById('provider-warning');
    if (!warningEl) return;

    const platformInfo = {
        music_assistant: {
            warning: 'Premium account must be configured in Music Assistant',
        },
        sonos: {
            warning: 'Spotify must be linked in Sonos app',
        },
        alexa_media: {
            warning: 'Service must be linked in Alexa app',
            caveat: 'Uses voice search - may occasionally play a different version of the song',
        },
        alexa: {
            warning: 'Service must be linked in Alexa app',
            caveat: 'Uses voice search - may occasionally play a different version of the song',
        },
    };

    const info = platformInfo[player.platform];
    if (info) {
        let html = `<p>⚠️ ${utils.escapeHtml(info.warning)}</p>`;
        if (info.caveat) {
            html += `<p class="warning-caveat">ℹ️ ${utils.escapeHtml(info.caveat)}</p>`;
        }
        warningEl.innerHTML = html;
        warningEl.classList.remove('hidden');
    } else {
        warningEl.classList.add('hidden');
    }
}
